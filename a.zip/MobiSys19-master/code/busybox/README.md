# Version
busybox 1.26.2

# Patch
Put `999-hp.patch` to `package/utils/busybox/patches`
