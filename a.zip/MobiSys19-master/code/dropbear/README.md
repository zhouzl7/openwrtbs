# Version
Dropbear 2016.74

# Patch
Put `999-hp.patch` to `package/network/services/dropbear/patches`
