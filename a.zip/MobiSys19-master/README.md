# Understanding Fileless Attacks on Linux-based IoT Devices with HoneyCloud


This code contains several parts:

- Modification of dropbear
- Modification of busybox
- A local server for forwarding data
- Other configs
